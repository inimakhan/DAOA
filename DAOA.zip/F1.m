
function o = F1(x)
o=sum(x.^2);
end
